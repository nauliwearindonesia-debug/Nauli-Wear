-- Skema database untuk Nauli Wear
-- Jalankan file ini di phpMyAdmin / MySQL hosting kamu sebelum deploy.

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    produk VARCHAR(100) NOT NULL,
    ukuran VARCHAR(10) DEFAULT '-',
    warna VARCHAR(50) DEFAULT '-',
    hp VARCHAR(20) NOT NULL,
    pembayaran VARCHAR(50) NOT NULL,
    alamat TEXT NOT NULL,
    rating TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
